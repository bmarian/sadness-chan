import Utils from "./Utils.js";
import portraitsList from "./lists/portraitsList.js";
import nat1CommentsList from "./lists/nat1CommentsList.js";
import nat20CommentsList from "./lists/nat20CommentsList.js";
import Settings from "./Settings.js";
class SadnessChan {
    constructor() {
        this._portraits = portraitsList;
        this._playerWhisperChance = 0.5;
    }
    static getInstance() {
        if (!SadnessChan._instance)
            SadnessChan._instance = new SadnessChan();
        return SadnessChan._instance;
    }
    /**
     * Selects a random portrait from portraitsList.ts
     */
    _getRandomPortrait(cssClass) {
        const portrait = Utils.getRandomItemFromList(this._portraits);
        if (!portrait)
            return '';
        return `
            <img
                src="${portrait}"
                alt="${Utils.moduleName}-portrait"
                class="${cssClass}__portrait"
            />
        `;
    }
    /**
     * Creates the display message
     *
     * @param content - the selected message
     */
    _sadnessMessage(content) {
        const chatMessageClass = `${Utils.moduleName}-chat-message`;
        const chatHeaderClass = `${chatMessageClass}-header`;
        const chatBodyClass = `${chatMessageClass}-body`;
        return `
            <div class="${chatMessageClass}">
                <div class="${chatHeaderClass}">
                    ${this._getRandomPortrait(chatHeaderClass)}
                    <h3 class="${chatHeaderClass}__name">
                        ${Utils.moduleTitle}
                    </h3>
                </div>
                <div class="${chatBodyClass}">
                    ${content}
                </div>
            </div>
        `;
    }
    /**
     * Creates body of the message for !sadness command
     *
     * @param userData - current user
     * @param statsBodyClass - css class for the body
     */
    _getStatsMessageBody(userData, statsBodyClass) {
        let message = `
            <h2 class="${statsBodyClass}__username">${userData.name}</h2>
        `;
        const rolls = userData.rolls;
        if (rolls) {
            const nat1 = rolls[1];
            const nat20 = rolls[20];
            const rollsClass = `${statsBodyClass}__rolls`;
            const rollClass = `${rollsClass}-roll`;
            message += `
                <ol class="${rollsClass}">
                    <li class="${rollClass}">
                        <span class="${rollClass}-dice min">1</span>    
                        <span class="${rollClass}-count">${nat1}</span>    
                    </li>
                    <li class="${rollClass}">
                        <span class="${rollClass}-dice max">20</span>    
                        <span class="${rollClass}-count">${nat20}</span>
                    </li>
                </ol>
            `;
        }
        return message;
    }
    /**
     * Decieds if the whisper should be sent to the user
     *
     * @param rolls - array of rolls made by the user
     */
    _shouldIWhisper(rolls) {
        if (!(Math.random() < this._playerWhisperChance && rolls && (rolls === null || rolls === void 0 ? void 0 : rolls.length)))
            return false;
        return !!(rolls[1] || rolls[20]);
    }
    /**
     * Creates and sends the whisper message
     *
     * @param target - who should receive the message
     * @param content - content of the message
     */
    async _createWhisperMessage(target, content) {
        return ChatMessage.create({
            user: target,
            content: this._sadnessMessage(content),
            whisper: [target],
            speaker: {
                alias: `${Utils.moduleTitle}`,
            },
        }, {
            chatBubble: false,
        });
    }
    /**
     * Updates messages that contain [sc-] tags
     *
     * @param message - the message that should have tags replaced
     * @param user - current user
     */
    _updateDynamicMessages(message, user) {
        const counter = Settings.getCounter();
        const userStructure = counter[user._id];
        let messageOutput = message.replace(/\[sc-d([0-9]{1,2})\]/, (_0, value) => {
            return userStructure.rolls[value];
        });
        messageOutput = messageOutput.replace(/\[sc-name\]/, () => {
            return user.name;
        });
        return messageOutput;
    }
    _selectNat1Comments(user) {
        const message = Utils.getRandomItemFromList(nat1CommentsList);
        return this._updateDynamicMessages(message, user);
    }
    _selectNat20Comments(user) {
        const message = Utils.getRandomItemFromList(nat20CommentsList);
        return this._updateDynamicMessages(message, user);
    }
    /**
     * Creates the stats message
     *
     * @param userData - current user
     */
    getStatsMessage(userData) {
        const statsClass = `${Utils.moduleName}-chat-stats`;
        const statsHeaderClass = `${statsClass}-header`;
        const statsBodyClass = `${statsClass}-body`;
        return `
            <div class="${statsClass}">
                <div class="${statsHeaderClass}">
                    ${this._getRandomPortrait(statsHeaderClass)}
                    <h3 class="${statsHeaderClass}__name">
                        ${Utils.moduleTitle}
                    </h3>
                </div>
                <div class="${statsBodyClass}">
                    ${this._getStatsMessageBody(userData, statsBodyClass)}
                </div>
            </div>
        `;
    }
    /**
     * Sends the whisper message
     *
     * @param rolls - array of rolls made by the user
     * @param user - current user
     */
    async whisper(rolls, user) {
        if (!this._shouldIWhisper(rolls))
            return;
        const content = rolls[1] > rolls[20] ? this._selectNat1Comments(user) : this._selectNat20Comments(user);
        Utils.debug(`Whisper sent to ${user.name}`);
        return this._createWhisperMessage(user._id, content);
    }
}
export default SadnessChan.getInstance();
