import utils from "./Utils.js";
import settingsList from "./lists/settingsList.js";
class Settings {
    constructor() {
        this._settingsList = settingsList;
        this._counterKey = 'counter';
    }
    static getInstance() {
        if (!Settings._instance)
            Settings._instance = new Settings();
        return Settings._instance;
    }
    _registerSetting(key, data) {
        game.settings.register(utils.moduleName, key, data);
    }
    _getSetting(key) {
        const setting = game.settings.get(utils.moduleName, key);
        try {
            return JSON.parse(setting);
        }
        catch (error) {
            return {};
        }
    }
    _setSetting(key, data) {
        return game.settings.set(utils.moduleName, key, JSON.stringify(data));
    }
    registerSettings() {
        this._settingsList.forEach((setting) => {
            this._registerSetting(setting.key, setting.data);
        });
        utils.debug('Settings registered', false);
    }
    getCounter() {
        return this._getSetting(this._counterKey);
    }
    setCounter(counterData) {
        return this._setSetting(this._counterKey, counterData);
    }
    resetStorage() {
        return this.setCounter({});
    }
}
export default Settings.getInstance();
