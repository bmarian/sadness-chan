import Utils from "../Utils.js";
import Settings from "../Settings.js";
import SadnessChan from "../SadnessChan.js";
class CreateChatMessage {
    constructor() {
    }
    static getInstance() {
        if (!CreateChatMessage._instance)
            CreateChatMessage._instance = new CreateChatMessage();
        return CreateChatMessage._instance;
    }
    async createChatMessageHook(chatMessage) {
        var _a;
        const user = (_a = chatMessage === null || chatMessage === void 0 ? void 0 : chatMessage.user) === null || _a === void 0 ? void 0 : _a.data;
        if (!(user && game.user.hasRole(4)))
            return;
        const result = await this._extractAnalytics(chatMessage === null || chatMessage === void 0 ? void 0 : chatMessage._roll, chatMessage, user);
        return await SadnessChan.whisper(result, user);
    }
    /**
     * Checks if Better 5e Rolls is installed
     */
    _checkIfBR5eIsInstalled() {
        return !!game.modules.get('betterrolls5e');
    }
    /**
     * Return an array filled with 0
     *
     * @param length - the length of the array
     */
    _getZeroArray(length) {
        const zeroArray = new Array(length);
        for (let i = 0; i < length; i++)
            zeroArray[i] = 0;
        return zeroArray;
    }
    /**
     * Extracts userId and userName from user
     *
     * @param user
     * @return {userId, userName} || null
     */
    _prepareUserDataForStorage(user) {
        const id = user === null || user === void 0 ? void 0 : user._id;
        const name = user === null || user === void 0 ? void 0 : user.name;
        return id && name ? { id: id, name: name } : null;
    }
    /**
     * Extracts rolls from the current message and returns an array with them
     *
     * @param _roll - a list of rolls for this message (not available in better5erolls
     * @param chatMessage - chat message data
     * @param user - current user
     * @return array of rolls
     */
    async _extractAnalytics(_roll, chatMessage, user) {
        var _a;
        if (_roll) {
            return await this._extractSimpleAnalytics(_roll, user);
        }
        if (this._checkIfBR5eIsInstalled() && ((_a = chatMessage === null || chatMessage === void 0 ? void 0 : chatMessage.data) === null || _a === void 0 ? void 0 : _a.content)) {
            return await this._extractBR5eAnalytics(chatMessage.data.content, user);
        }
        // TODO: Extract analytics from embedded rolls
        return [];
    }
    /**
     * Extracts data from a normal roll
     *
     * @param roll - all the rolls in this message
     * @param user - current user
     * @return an array with all the recent rolls
     */
    async _extractSimpleAnalytics(roll, user) {
        const dice = roll._dice;
        if (!dice)
            return;
        const recentRolls = this._getZeroArray(21);
        dice.forEach((die) => {
            if (die.faces !== 20)
                return;
            die.rolls.forEach((roll) => {
                const r = roll.roll;
                recentRolls[r] += 1;
            });
        });
        await this._updateDiceRolls(recentRolls, this._prepareUserDataForStorage(user));
        Utils.debug('Analytics extracted from simple roll.');
        return recentRolls;
    }
    /**
     * Extracts data from Better 5e Rolls
     *
     * @param chatMessage - chat message content
     * @param user - current user
     * @return an array with all the recent rolls
     */
    async _extractBR5eAnalytics(chatMessage, user) {
        const rolls = [...chatMessage.matchAll(/<li.*roll die d20.*>([0-9]+)<\/li>/g)];
        if (!rolls)
            return;
        const recentRolls = this._getZeroArray(21);
        rolls.forEach((roll) => {
            const value = roll[1];
            if (!value)
                return;
            recentRolls[value] += 1;
        });
        await this._updateDiceRolls(recentRolls, this._prepareUserDataForStorage(user));
        Utils.debug('Analytics extracted from betterrolls5e.');
        return recentRolls;
    }
    /**
     * Updates the values saved for user rolls.
     *
     * @param recentRolls - an array of how many of each roll
     * @param userData - extracted {userId, userName} from user
     */
    _updateDiceRolls(recentRolls, userData) {
        if (!userData)
            return;
        const counter = Settings.getCounter();
        const storedUser = counter[userData.id];
        if (storedUser && storedUser.rolls) {
            storedUser.name = userData.name;
            const storedUserRolls = storedUser.rolls;
            recentRolls.forEach((roll, index) => {
                if (index === 0)
                    return;
                storedUserRolls[index] = storedUserRolls[index] ? storedUserRolls[index] + roll : roll;
            });
        }
        else {
            // First time setup, when user has no data
            counter[userData.id] = Object.assign({ rolls: [...recentRolls] }, userData);
        }
        return Settings.setCounter(counter);
    }
}
export default CreateChatMessage.getInstance();
