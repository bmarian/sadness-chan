var SettingEnum;
(function (SettingEnum) {
    SettingEnum["FAIL_CHANCE"] = "failComChance";
    SettingEnum["SUCCESS_CHANCE"] = "successComChance";
    SettingEnum["CMD_SYMBOL"] = "cmdSymbol";
    SettingEnum["STATS_CMD"] = "statsCmd";
    SettingEnum["DIE_TYPE"] = "dieType";
    SettingEnum["CRT_FAIL"] = "crtFail";
    SettingEnum["CRT_SUCCESS"] = "crtSuccess";
    SettingEnum["COUNTER"] = "counter";
    SettingEnum["LISTS"] = "lists";
    SettingEnum["LISTS_EDITOR"] = "listsEditor";
})(SettingEnum || (SettingEnum = {}));
export default SettingEnum;
