export default [
    'Yet another failure maybe you should reconsider your life.',
    'Hmm I think your parents also rolled a nat 1 when you were born.',
    'Wow you are really trash you rolled [sc-d1] nat ones.',
    'A powerful blow?!',
    'Look out below!',
    'You meant to do that.',
    'Your true skill shines through!',
    'Consider being a halfling in your next life...',
    'You realise you are ruining your party\'s fun? Right? ... ',
    'Tell the poor monster you are sorry for wasting it\'s time',
    'You only got [sc-d1] more of those.',
    'One more fail added to the collection.'
];
