import Settings from "../Settings.js";
import SadnessChan from "../SadnessChan.js";
import Utils from "../Utils.js";
class PreCreateChatMessage {
    constructor() {
    }
    static getInstance() {
        if (!PreCreateChatMessage._instance)
            PreCreateChatMessage._instance = new PreCreateChatMessage();
        return PreCreateChatMessage._instance;
    }
    preCreateChatMessageHook(message, options) {
        const content = message === null || message === void 0 ? void 0 : message.content;
        const user = message === null || message === void 0 ? void 0 : message.user;
        const counter = Settings.getCounter();
        if (!(user && content))
            return;
        if (content === SadnessChan.buildStatsCmd() && counter && counter[user]) {
            this._sendStatsMessage(message, options, counter[user], user);
            Utils.debug('Sad stats displayed.');
        }
    }
    _sendStatsMessage(message, options, userData, userId) {
        message.content = SadnessChan.getStatsMessage(userData);
        this._prepareMessage(message, options, userId);
    }
    _prepareMessage(message, options, userId) {
        message.whisper = [userId];
        message.speaker = { alias: `${Utils.moduleTitle}` };
        options.chatBubble = false;
    }
}
export default PreCreateChatMessage.getInstance();
