import Settings from "../Settings.js";
import SadnessChan from "../SadnessChan.js";
import Utils from "../Utils.js";
import settingsDefaults from "../lists/settingsDefaults.js";
class PreCreateChatMessage {
    constructor() {
        this._errorMessages = settingsDefaults.ERROR_MESSAGES;
    }
    static getInstance() {
        if (!PreCreateChatMessage._instance)
            PreCreateChatMessage._instance = new PreCreateChatMessage();
        return PreCreateChatMessage._instance;
    }
    _executeResetCmd(args) {
        if (!game.user.hasRole(4)) {
            return Utils.notifyUser("error", this._errorMessages.NOT_ENOUGH_PERMISSIONS);
        }
        switch (args) {
            case "settings":
                Settings.resetAllSettings();
                Utils.notifyUser("info", this._errorMessages.SETTINGS_RESET);
                break;
            case "counter":
                Settings.resetCounter();
                Utils.notifyUser("info", this._errorMessages.COUNTER_RESET);
                break;
            case "lists":
                Settings.resetLists();
                Utils.notifyUser("info", this._errorMessages.LISTS_RESET);
                break;
            default:
                Utils.notifyUser("error", this._errorMessages.INVALID_ARGUMENTS);
                break;
        }
    }
    _prepareMessage(message, options, userId) {
        message.whisper = [userId];
        message.speaker = { alias: `${Utils.moduleTitle}` };
        options.chatBubble = false;
    }
    _sendStatsMessage(message, options, userData, userId) {
        message.content = SadnessChan.getStatsMessage(userData);
        this._prepareMessage(message, options, userId);
    }
    _executeStatsCmd(message, options, user) {
        const counter = Settings.getCounter();
        if (counter && counter[user]) {
            this._sendStatsMessage(message, options, counter[user], user);
            Utils.debug('Sad stats displayed.');
        }
    }
    executeCommand(args) {
        const resetCommand = 'reset';
        if (args.startsWith(resetCommand)) {
            return this._executeResetCmd(args.replace(resetCommand + ' ', ''));
        }
    }
    preCreateChatMessageHook(message, options) {
        const content = message === null || message === void 0 ? void 0 : message.content;
        const user = message === null || message === void 0 ? void 0 : message.user;
        const command = SadnessChan.getCmd();
        if (!(user && content && content.startsWith(command)))
            return;
        if (content === command)
            return this._executeStatsCmd(message, options, user);
        this.executeCommand(content.replace(command + ' ', ''));
    }
}
export default PreCreateChatMessage.getInstance();
