import Settings from "../Settings.js";
import Utils from "../Utils.js";
class Init {
    constructor() {
    }
    static getInstance() {
        if (!Init._instance)
            Init._instance = new Init();
        return Init._instance;
    }
    async initHook() {
        Settings.registerSettings();
        // Settings.resetStorage();
        Utils.debug('Prepared to collect tears.');
    }
}
export default Init.getInstance();
