import utils from "./Utils.js";
import settingsList from "./lists/settingsList.js";
import settingNames from "./lists/settingEnum.js";
import ListsEditor from "./apps/ListsEditor.js";
import defaultCrtFailCom from "./lists/defaultCrtFailCom.js";
import defaultCrtSuccessCom from "./lists/defaultCrtSuccessCom.js";
class Settings {
    constructor() {
        this._settingsList = settingsList;
    }
    static getInstance() {
        if (!Settings._instance)
            Settings._instance = new Settings();
        return Settings._instance;
    }
    _registerSetting(key, data) {
        game.settings.register(utils.moduleName, key, data);
    }
    _registerMenus() {
        // @ts-ignore
        game.settings.registerMenu(utils.moduleName, settingNames.LISTS_EDITOR, {
            name: "Custom Comments Menu",
            label: "Open comments editor",
            icon: "fas fa-edit",
            type: ListsEditor,
            restricted: true,
        });
    }
    _registerLists() {
        const defaultList = JSON.stringify({
            'fail': [...defaultCrtFailCom],
            'success': [...defaultCrtSuccessCom],
            'portraits': [],
        });
        this._registerSetting(settingNames.LISTS, {
            type: String,
            default: defaultList,
            scope: "world",
            config: false,
            restricted: true,
        });
    }
    _getSetting(key) {
        return game.settings.get(utils.moduleName, key);
    }
    _setSetting(key, data) {
        return game.settings.set(utils.moduleName, key, JSON.stringify(data));
    }
    resetCounter() {
        return this.setCounter({});
    }
    registerSettings() {
        this._registerLists();
        this._registerMenus();
        this._settingsList.forEach((setting) => {
            this._registerSetting(setting.key, setting.data);
        });
        utils.debug('Settings registered', false);
    }
    getSetting(key) {
        return this._getSetting(key);
    }
    setSetting(key, data) {
        return game.settings.set(utils.moduleName, key, data);
    }
    setCounter(counterData) {
        return this._setSetting(settingNames.COUNTER, counterData);
    }
    getCounter() {
        const setting = this.getSetting(settingNames.COUNTER);
        try {
            return JSON.parse(setting);
        }
        catch (error) {
            return {};
        }
    }
    setLists(listsData) {
        return this._setSetting(settingNames.LISTS, listsData);
    }
    getLists() {
        const setting = this.getSetting(settingNames.LISTS);
        try {
            return JSON.parse(setting);
        }
        catch (error) {
            return {};
        }
    }
}
export default Settings.getInstance();
