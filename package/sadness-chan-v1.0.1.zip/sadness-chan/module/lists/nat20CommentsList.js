export default [
    'Wow the algorithm is broken, you rolled above a 1. Let\'s fix that.',
    'You just learned to count above a 1, you will forget that soon enough...',
    'Who needs skill when you have luck...',
    'Don\'t count on ever doing that again.',
    'Even a blind dwarf finds a gem once in a while',
    'You already have [sc-d20] of those. Are you collecting them? ... dice goblin ಠ_ಠ',
    '[sc-name] has been banned for hacking...',
    'Do that again... oh you can\'t ?',
    'What are you trying to prove?'
];
