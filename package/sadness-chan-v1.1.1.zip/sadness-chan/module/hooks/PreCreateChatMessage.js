import Settings from "../Settings.js";
import SadnessChan from "../SadnessChan.js";
import Utils from "../Utils.js";
import settingsDefaults from "../lists/settingsDefaults.js";
class PreCreateChatMessage {
    constructor() {
        this._errorMessages = settingsDefaults.ERROR_MESSAGES;
    }
    static getInstance() {
        if (!PreCreateChatMessage._instance)
            PreCreateChatMessage._instance = new PreCreateChatMessage();
        return PreCreateChatMessage._instance;
    }
    _executeResetCmd(args, message, options, user) {
        let content = this._errorMessages.NOT_ENOUGH_PERMISSIONS;
        if (game.user.hasRole(4)) {
            switch (args) {
                case "settings":
                    Settings.resetAllSettings();
                    content = this._errorMessages.SETTINGS_RESET;
                    break;
                case "counter":
                    Settings.resetCounter();
                    content = this._errorMessages.COUNTER_RESET;
                    break;
                case "lists":
                    Settings.resetLists();
                    content = this._errorMessages.LISTS_RESET;
                    break;
                default:
                    content = this._errorMessages.INVALID_ARGUMENTS;
                    break;
            }
        }
        message.content = SadnessChan.generateMessageStructure(content);
        this._prepareMessage(message, options, user, true);
    }
    _prepareMessage(message, options, userId, sendToAll) {
        const isPublic = Settings.getSetting(settingsDefaults.SETTING_KEYS.STATS_MESSAGE_VISIBILITY);
        message.whisper = isPublic || sendToAll ? [] : [userId];
        message.speaker = { alias: `${Utils.moduleTitle}` };
        options.chatBubble = false;
    }
    _sendStatsMessage(message, options, userData, userId) {
        message.content = SadnessChan.getStatsMessage(userData);
        this._prepareMessage(message, options, userId);
    }
    _executeStatsCmd(message, options, user) {
        const counter = Settings.getCounter();
        if (counter && counter[user]) {
            this._sendStatsMessage(message, options, counter[user], user);
            Utils.debug('Sad stats displayed.');
        }
    }
    _sendAllRollsMessage(message, options, userId) {
        const counter = Settings.getCounter();
        const rolls = counter[userId]?.rolls;
        if (!(counter && rolls))
            return;
        message.content = rolls.reduce((result, el, index) => {
            return !index ? '' : result + `${index} ${el}<br>`;
        }, '');
        this._prepareMessage(message, options, userId);
    }
    executeCommand(args, user, message, options) {
        const resetCommand = 'reset';
        const allCommand = 'all';
        if (args.startsWith(resetCommand)) {
            return this._executeResetCmd(args.replace(resetCommand + ' ', ''), message, options, user);
        }
        if (args.startsWith(allCommand)) {
            return this._sendAllRollsMessage(message, options, user);
        }
    }
    preCreateChatMessageHook(message, options) {
        const content = message?.content;
        const user = message?.user;
        const command = SadnessChan.getCmd();
        if (!(user && content && content.startsWith(command)))
            return;
        if (content === command)
            return this._executeStatsCmd(message, options, user);
        return this.executeCommand(content.replace(command + ' ', ''), user, message, options);
    }
}
export default PreCreateChatMessage.getInstance();
